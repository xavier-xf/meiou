#include <stdio.h>
#include <unistd.h>

#include "sat_ipcamera.h"
#include "sat_user_common.h"




int main(){
    LOG_WHITE("start ++++++++++++\n");


    sat_ipcamera_device_discover_search(0);

    while (sat_ipcamera_status_get())
    {
        LOG_WHITE("busy...");
        usleep(1000*1000);
    }

    int total = sat_ipcamera_online_num_get();
    LOG_WHITE("online = %d\n", total);
    for (int i = 0; i < total; i++){
        
        sat_ipcamera_user_password_set(i, "zhangsan","123456");

        int i = 0;
        if(sat_ipcamera_rtsp_url_get(i) == true){
            while (sat_ipcamera_status_get())
            {
                LOG_WHITE("busy...");
                usleep(1000*1000);
            }

            int nstream = sat_ipcamera_profile_token_num_get(i);
            for (int s = 0; s < nstream; s++){
                LOG_WHITE("%d:%s\n", s + 1, sat_ipcamera_rtsp_addr_get(i, s));
            }

        }
    
    }
    
    LOG_WHITE("done -------------\n");


}