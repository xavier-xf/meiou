
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/xiaole/smb/ipc_onvif_demo/open_source_libraries/base64/bin/base64.c" "open_source_libraries/base64/CMakeFiles/base64-bin.dir/bin/base64.c.o" "gcc" "open_source_libraries/base64/CMakeFiles/base64-bin.dir/bin/base64.c.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  "/home/xiaole/smb/ipc_onvif_demo/.build/open_source_libraries/base64/CMakeFiles/base64.dir/DependInfo.cmake"
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
