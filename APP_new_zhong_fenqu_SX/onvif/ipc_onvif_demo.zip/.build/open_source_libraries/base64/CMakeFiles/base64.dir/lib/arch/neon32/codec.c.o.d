open_source_libraries/base64/CMakeFiles/base64.dir/lib/arch/neon32/codec.c.o: \
 /home/xiaole/smb/ipc_onvif_demo/open_source_libraries/base64/lib/arch/neon32/codec.c \
 /usr/include/stdc-predef.h \
 /usr/lib/gcc/x86_64-linux-gnu/9/include/stdint.h /usr/include/stdint.h \
 /usr/include/x86_64-linux-gnu/bits/libc-header-start.h \
 /usr/include/features.h /usr/include/x86_64-linux-gnu/sys/cdefs.h \
 /usr/include/x86_64-linux-gnu/bits/wordsize.h \
 /usr/include/x86_64-linux-gnu/bits/long-double.h \
 /usr/include/x86_64-linux-gnu/gnu/stubs.h \
 /usr/include/x86_64-linux-gnu/gnu/stubs-64.h \
 /usr/include/x86_64-linux-gnu/bits/types.h \
 /usr/include/x86_64-linux-gnu/bits/timesize.h \
 /usr/include/x86_64-linux-gnu/bits/typesizes.h \
 /usr/include/x86_64-linux-gnu/bits/time64.h \
 /usr/include/x86_64-linux-gnu/bits/wchar.h \
 /usr/include/x86_64-linux-gnu/bits/stdint-intn.h \
 /usr/include/x86_64-linux-gnu/bits/stdint-uintn.h \
 /usr/lib/gcc/x86_64-linux-gnu/9/include/stddef.h /usr/include/string.h \
 /usr/include/x86_64-linux-gnu/bits/string_fortified.h \
 /home/xiaole/smb/ipc_onvif_demo/open_source_libraries/base64/lib/arch/neon32/../../../include/libbase64.h \
 /home/xiaole/smb/ipc_onvif_demo/open_source_libraries/base64/lib/arch/neon32/../../tables/tables.h \
 /home/xiaole/smb/ipc_onvif_demo/open_source_libraries/base64/lib/arch/neon32/../../tables/../env.h \
 /home/xiaole/smb/ipc_onvif_demo/open_source_libraries/base64/lib/arch/neon32/../../codecs.h \
 /home/xiaole/smb/ipc_onvif_demo/open_source_libraries/base64/lib/arch/neon32/../../../include/libbase64.h \
 /home/xiaole/smb/ipc_onvif_demo/.build/open_source_libraries/base64/config.h \
 /home/xiaole/smb/ipc_onvif_demo/open_source_libraries/base64/lib/arch/neon32/../../env.h
