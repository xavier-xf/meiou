
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/xiaole/smb/ipc_onvif_demo/open_source_libraries/mxml-3.3.1/mxml-attr.c" "open_source_libraries/mxml-3.3.1/CMakeFiles/mxml.dir/mxml-attr.c.o" "gcc" "open_source_libraries/mxml-3.3.1/CMakeFiles/mxml.dir/mxml-attr.c.o.d"
  "/home/xiaole/smb/ipc_onvif_demo/open_source_libraries/mxml-3.3.1/mxml-entity.c" "open_source_libraries/mxml-3.3.1/CMakeFiles/mxml.dir/mxml-entity.c.o" "gcc" "open_source_libraries/mxml-3.3.1/CMakeFiles/mxml.dir/mxml-entity.c.o.d"
  "/home/xiaole/smb/ipc_onvif_demo/open_source_libraries/mxml-3.3.1/mxml-file.c" "open_source_libraries/mxml-3.3.1/CMakeFiles/mxml.dir/mxml-file.c.o" "gcc" "open_source_libraries/mxml-3.3.1/CMakeFiles/mxml.dir/mxml-file.c.o.d"
  "/home/xiaole/smb/ipc_onvif_demo/open_source_libraries/mxml-3.3.1/mxml-get.c" "open_source_libraries/mxml-3.3.1/CMakeFiles/mxml.dir/mxml-get.c.o" "gcc" "open_source_libraries/mxml-3.3.1/CMakeFiles/mxml.dir/mxml-get.c.o.d"
  "/home/xiaole/smb/ipc_onvif_demo/open_source_libraries/mxml-3.3.1/mxml-node.c" "open_source_libraries/mxml-3.3.1/CMakeFiles/mxml.dir/mxml-node.c.o" "gcc" "open_source_libraries/mxml-3.3.1/CMakeFiles/mxml.dir/mxml-node.c.o.d"
  "/home/xiaole/smb/ipc_onvif_demo/open_source_libraries/mxml-3.3.1/mxml-private.c" "open_source_libraries/mxml-3.3.1/CMakeFiles/mxml.dir/mxml-private.c.o" "gcc" "open_source_libraries/mxml-3.3.1/CMakeFiles/mxml.dir/mxml-private.c.o.d"
  "/home/xiaole/smb/ipc_onvif_demo/open_source_libraries/mxml-3.3.1/mxml-search.c" "open_source_libraries/mxml-3.3.1/CMakeFiles/mxml.dir/mxml-search.c.o" "gcc" "open_source_libraries/mxml-3.3.1/CMakeFiles/mxml.dir/mxml-search.c.o.d"
  "/home/xiaole/smb/ipc_onvif_demo/open_source_libraries/mxml-3.3.1/mxml-string.c" "open_source_libraries/mxml-3.3.1/CMakeFiles/mxml.dir/mxml-string.c.o" "gcc" "open_source_libraries/mxml-3.3.1/CMakeFiles/mxml.dir/mxml-string.c.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
