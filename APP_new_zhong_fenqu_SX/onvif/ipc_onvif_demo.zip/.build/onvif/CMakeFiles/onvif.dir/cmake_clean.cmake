file(REMOVE_RECURSE
  "CMakeFiles/onvif.dir/onvif.c.o"
  "CMakeFiles/onvif.dir/onvif.c.o.d"
  "CMakeFiles/onvif.dir/onvif_user_token.c.o"
  "CMakeFiles/onvif.dir/onvif_user_token.c.o.d"
  "CMakeFiles/onvif.dir/sat_ipcamera.c.o"
  "CMakeFiles/onvif.dir/sat_ipcamera.c.o.d"
  "CMakeFiles/onvif.dir/sat_user_common.c.o"
  "CMakeFiles/onvif.dir/sat_user_common.c.o.d"
  "libonvif.a"
  "libonvif.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/onvif.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
