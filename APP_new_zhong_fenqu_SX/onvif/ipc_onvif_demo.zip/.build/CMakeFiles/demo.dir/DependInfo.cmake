
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/xiaole/smb/ipc_onvif_demo/main.c" "CMakeFiles/demo.dir/main.c.o" "gcc" "CMakeFiles/demo.dir/main.c.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  "/home/xiaole/smb/ipc_onvif_demo/.build/onvif/CMakeFiles/onvif.dir/DependInfo.cmake"
  "/home/xiaole/smb/ipc_onvif_demo/.build/open_source_libraries/base64/CMakeFiles/base64.dir/DependInfo.cmake"
  "/home/xiaole/smb/ipc_onvif_demo/.build/open_source_libraries/md5/CMakeFiles/md5.dir/DependInfo.cmake"
  "/home/xiaole/smb/ipc_onvif_demo/.build/open_source_libraries/sha1/CMakeFiles/sha1.dir/DependInfo.cmake"
  "/home/xiaole/smb/ipc_onvif_demo/.build/open_source_libraries/mxml-3.3.1/CMakeFiles/mxml.dir/DependInfo.cmake"
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
