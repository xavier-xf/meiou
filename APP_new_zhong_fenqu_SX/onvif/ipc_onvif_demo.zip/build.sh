SHELL_FOLDER=$(cd "$(dirname "$0")";pwd)
buildDir=".build"


make_all(){

    cd $SHELL_FOLDER

    mkdir -p $buildDir
    cd $buildDir
    cmake ..
    make -j12
    
    cd ..
}





make_clean(){
    # 清除编译产生的中间文件
    find . -name "$buildDir" | xargs rm -rf
    find . -name "Makefile" | xargs rm -rf
    find . -name "CMakeFiles" | xargs rm -rf
    find . -name "CMakeCache.txt" | xargs rm -rf
    find . -name "cmake_install.cmake" | xargs rm -rf
}

make_lib(){ # [1] 路径

# """
#     # 需要先修改CmakeLists.txx
#     add_definitions(
#     )
#     include_directories(
#         .
#     )
#     add_library(md5 STATIC
#             ./md5.c
#     )

#     # 这里指定需要安装的文件
#     install(TARGETS md5 DESTINATION lib)
#     install(FILES md5.h DESTINATION include)

# """
    cd $SHELL_FOLDER
    if [ ! -d $1 ];then
        echo "PWD=$PWD"
        echo "'$1' not exists!!!"
        exit
    fi

    cd $1

    # 清除编译产生的中间文件
    rm -rf $buildDir

    rm -rf CMakeFiles
    rm -rf cmake_install.cmake
    rm -rf CMakeCache.txt
    rm -rf Makefile

    mkdir -p $buildDir
    cd $buildDir
    cmake .. -DCMAKE_C_COMPILER="arm-anykav500-linux-uclibcgnueabi-gcc" \
             -DCMAKE_C_STANDARD="11"  \
             -DCMAKE_INSTALL_PREFIX="$PWD/install"

    make -j12
    make install

}




# make_clean
make_all
