#include "layout_define.h"
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include "video_input.h"

#include "ak_common_graphics.h"
#include "ak_tde.h"

#define FRAME_1_FILE_PATH "/etc/config/run/wallpaper/frame_1.jpg" //"/mnt/res/wallpaper/frame_1.jpg"
#define FRAME_2_FILE_PATH "/etc/config/run/wallpaper/frame_2.jpg" //"/mnt/res/wallpaper/frame_2.jpg"

#define LAYOUT_FRAME_SHOW_OBJ_ID_FRAME_0_CANCEL 0x0A
#define LAYOUT_FRAME_SHOW_OBJ_ID_FRAME_0_CONT 0X02
#define LAYOUT_FRAME_SHOW_OBJ_ID_FRAME_0_HOUR 0X03
#define LAYOUT_FRAME_SHOW_OBJ_ID_FRAME_0_MIN 0X04
#define LAYOUT_FRAME_SHOW_OBJ_ID_FRAME_0_DOT 0X05
#define LAYOUT_FRAME_SHOW_OBJ_ID_FRAME_0_SETTING 0X10

#define LAYOUT_FRAME_SHOW_OBJ_ID_FRAME_0_DATE_CONT 0X0C
#define LAYOUT_FRAME_SHOW_OBJ_ID_FRAME_0_DATE_TXT 0X0E

/***** 解码帧缓存 *****/
static unsigned char *frame_buffer_a = NULL;

static unsigned char *frame_buffer_cur_a = NULL;
static unsigned char *frame_buffer_cur_b = NULL;

/***** 已经送去解码的文件索引 *****/
static char frame_display_decode_file_index = 0;

static int frame_dislay_effeset_x = 0;
/***** 数据已经解码完毕 *****/
static bool jpg_decode_finish = false;

static void frame_show_cancel_btn_up(lv_obj_t *obj)
{
	goto_layout(pLAYOUT(home));
}

static void frame_show_cancel_btn_create(void)
{
	static obj_click_data click_data = obj_click_data_up_create(frame_show_cancel_btn_up);
	static rom_bin_info img = rom_bin_info_get(ROM_UI_WALLPAPER_HOME_PNG);
	lv_obj_t *obj = lv_obj_create(lv_scr_act(), NULL);
	lv_obj_set_id(obj, LAYOUT_FRAME_SHOW_OBJ_ID_FRAME_0_CANCEL);
	lv_obj_set_pos(obj, 10, 10);
	lv_obj_set_size(obj, 100, 100);
	lv_obj_set_style_local_pattern_image(obj, LV_OBJ_PART_MAIN, LV_STATE_DEFAULT, &img);
	obj_click_event_listen(obj, &click_data);
}

static void frame_show_setting_btn_up(lv_obj_t *obj)
{
	goto_layout(pLAYOUT(setting_frame));
}
/***
** 日期: 2022-05-11 08:19
** 作者: leo.liu
** 函数作用：创建设置按钮
** 返回参数说明：
***/
static void frame_show_setting_btn_create(void)
{
	static obj_click_data click_data = obj_click_data_up_create(frame_show_setting_btn_up);
	static rom_bin_info img = rom_bin_info_get(ROM_UI_02_BTN_BTN_TITLE_SETTING_PNG);
	lv_obj_t *obj = lv_obj_create(lv_scr_act(), NULL);
	lv_obj_set_id(obj, LAYOUT_FRAME_SHOW_OBJ_ID_FRAME_0_SETTING);
	lv_obj_set_pos(obj, 1170, 10);
	lv_obj_set_size(obj, 100, 100);
	lv_obj_set_style_local_pattern_image(obj, LV_OBJ_PART_MAIN, LV_STATE_DEFAULT, &img);
	obj_click_event_listen(obj, &click_data);
}

/***
** 日期: 2022-05-10 16:04
** 作者: leo.liu
** 函数作用：初始化帧页面
** 返回参数说明：
***/
static void frame_show_layer_init(void)
{
	frame_buffer_a = ak_mem_dma_alloc(MODULE_ID_VDEC, LV_HOR_RES_MAX * LV_VER_RES_MAX * 2);
	frame_buffer_cur_a = ak_mem_dma_alloc(MODULE_ID_VDEC, LV_HOR_RES_MAX * LV_VER_RES_MAX * 2);
	frame_buffer_cur_b = ak_mem_dma_alloc(MODULE_ID_VDEC, LV_HOR_RES_MAX * LV_VER_RES_MAX * 2);
	frame_dislay_effeset_x = 0;
	frame_display_decode_file_index = 0;
}

/***
** 日期: 2022-05-10 14:56
** 作者: leo.liu
** 函数作用：解码获取到的数据
** 返回参数说明：
***/
static void jpg_decode_frame_read_func(struct ak_vdec_frame *frame)
{
	printf("read: w:%d h:%d \n", frame->width, frame->height);
	if ((jpg_decode_finish == true) || (frame_buffer_a == NULL))
	{
		return;
	}

	struct ak_tde_layer src, dst;
	tde_layer_layer_init(src, GP_FORMAT_YUV420SP,
			     frame->frame_obj.data.pitch_width, frame->frame_obj.data.pitch_height,
			     0, 0, frame->width, frame->height);
	ak_mem_dma_vaddr2paddr(frame->frame_obj.data.data, (unsigned long *)&src.phyaddr);

	tde_layer_layer_init(dst, GP_FORMAT_RGB565,
			     LV_HOR_RES_MAX, LV_VER_RES_MAX,
			     0, 0, LV_HOR_RES_MAX, LV_VER_RES_MAX);
	ak_mem_dma_vaddr2paddr(frame_buffer_a, (unsigned long *)&dst.phyaddr);
	ak_tde_opt_blit(&src, &dst);

	jpg_decode_finish = true;
}

/***
** 日期: 2022-05-10 18:35
** 作者: leo.liu
** 函数作用：读取文件送入解码
** 返回参数说明：
***/
static void frame_show_read_jpg_and_decode(const char *path)
{
	jpg_decode_finish = false;

	int fd = open(path, O_RDONLY);
	int size = lseek(fd, 0, SEEK_END);
	lseek(fd, 0, SEEK_SET);
	unsigned char *data = ak_mem_alloc(MODULE_ID_VDEC, size);
	read(fd, data, size);
	close(fd);
	jpg_decode_stream_write(data, size);
	ak_mem_free(data);
	printf("decode:%s \n", path);
}

/***
** 日期: 2022-05-10 19:39
** 作者: leo.liu
** 函数作用：交换buffer
** 返回参数说明：
***/
static void frame_loading_1_buffer_task(lv_task_t *task_t);
static void frame_show_swap_buffer_task(lv_task_t *task)
{
	frame_show_read_jpg_and_decode(frame_display_decode_file_index == 0 ? FRAME_2_FILE_PATH : FRAME_1_FILE_PATH);
	/***** 等待1加载后自动加载2 *****/
	frame_display_decode_file_index = frame_display_decode_file_index == 0 ? 1 : 0;
	lv_layout_task_create(frame_loading_1_buffer_task, 10, LV_TASK_PRIO_MID, NULL);
	lv_task_del(task);
}

static void frame_show_animation_effect_task(lv_task_t *task_t)
{
	if (jpg_decode_finish == false)
	{
		return;
	}

	if ((frame_buffer_cur_b == NULL) || (frame_buffer_cur_b == NULL))
	{
		lv_task_del(task_t);
		return;
	}

#define FRAME_STEP 20 // 24//40 // 40
	frame_dislay_effeset_x += FRAME_STEP;

	struct ak_tde_layer src, dst;
	int x = frame_dislay_effeset_x;
	tde_layer_layer_init(src, GP_FORMAT_RGB565, LV_HOR_RES_MAX, LV_VER_RES_MAX, LV_HOR_RES_MAX - x, 0, x, LV_VER_RES_MAX);
	ak_mem_dma_vaddr2paddr(frame_buffer_cur_b, (unsigned long *)&src.phyaddr);
	tde_layer_layer_init(dst, GP_FORMAT_RGB565, LV_HOR_RES_MAX, LV_VER_RES_MAX, 0, 0, x, LV_VER_RES_MAX);
	ak_mem_dma_vaddr2paddr(gui_full_varaddr_get(), (unsigned long *)&dst.phyaddr);
	ak_tde_opt_blit(&src, &dst);

	if (frame_dislay_effeset_x < 1280)
	{
		tde_layer_layer_init(src, GP_FORMAT_RGB565, LV_HOR_RES_MAX, LV_VER_RES_MAX, 0, 0, LV_HOR_RES_MAX - x, LV_VER_RES_MAX);
		ak_mem_dma_vaddr2paddr(frame_buffer_cur_a, (unsigned long *)&src.phyaddr);
		tde_layer_layer_init(dst, GP_FORMAT_RGB565, LV_HOR_RES_MAX, LV_VER_RES_MAX, x, 0, LV_HOR_RES_MAX - x, LV_VER_RES_MAX);
		ak_tde_opt_blit(&src, &dst);
	}
	else
	{
		lv_layout_task_create(frame_show_swap_buffer_task, 3000, LV_TASK_PRIO_MID, NULL);
		lv_task_del(task_t);
	}

	screen_force_refresh();
}

/***
** 日期: 2022-05-10 18:36
** 作者: leo.liu
** 函数作用：加载第二个buffer
** 返回参数说明：
***/
static void frame_loading_2_buffer_copy_task(lv_task_t *task_t)
{
	struct ak_tde_layer src, dst;
	tde_layer_layer_init(src, GP_FORMAT_RGB565, 1280, 800, 0, 0, 1280, 800);
	ak_mem_dma_vaddr2paddr(gui_full_varaddr_get(), (unsigned long *)&src.phyaddr);
	tde_layer_layer_init(dst, GP_FORMAT_RGB565, 1280, 800, 0, 0, 1280, 800);
	ak_mem_dma_vaddr2paddr(frame_buffer_cur_b, (unsigned long *)&dst.phyaddr);
	ak_tde_opt_blit(&src, &dst);

	frame_dislay_effeset_x = 0;
	lv_layout_task_create(frame_show_animation_effect_task, 20, LV_TASK_PRIO_HIGHEST, NULL);
	lv_obj_invalidate(lv_scr_act());

	lv_task_del(task_t);
}

static void frame_loading_2_buffer_task(lv_task_t *task_t)
{
	if (jpg_decode_finish == false)
	{
		return;
	}
	lv_obj_invalidate(lv_scr_act());
	/***** 等待1加载后自动加载2 *****/
	lv_layout_task_create(frame_loading_2_buffer_copy_task, 100, LV_TASK_PRIO_MID, NULL);
	lv_obj_invalidate(lv_scr_act());
	lv_task_del(task_t);
}

/***
** 日期: 2022-05-10 18:36
** 作者: leo.liu
** 函数作用：加载第二个buffer
** 返回参数说明：
***/
static void frame_loading_1_buffer_copy_task(lv_task_t *task_t)
{
	gui_refresh_enable(false);
	struct ak_tde_layer src, dst;
	tde_layer_layer_init(src, GP_FORMAT_RGB565, 1280, 800, 0, 0, 1280, 800);
	ak_mem_dma_vaddr2paddr(gui_full_varaddr_get(), (unsigned long *)&src.phyaddr);
	tde_layer_layer_init(dst, GP_FORMAT_RGB565, 1280, 800, 0, 0, 1280, 800);
	ak_mem_dma_vaddr2paddr(frame_buffer_cur_a, (unsigned long *)&dst.phyaddr);
	ak_tde_opt_blit(&src, &dst);

	frame_show_read_jpg_and_decode(frame_display_decode_file_index == 0 ? FRAME_2_FILE_PATH : FRAME_1_FILE_PATH);

	frame_dislay_effeset_x = 0;
	lv_layout_task_create(frame_loading_2_buffer_task, 3000, LV_TASK_PRIO_HIGHEST, NULL);

	lv_task_del(task_t);
}

/***
** 日期: 2022-05-10 18:36
** 作者: leo.liu
** 函数作用：加载第一个buffer
** 返回参数说明：
***/
static void frame_loading_1_buffer_task(lv_task_t *task_t)
{
	if (jpg_decode_finish == false)
	{
		return;
	}
	gui_refresh_enable(true);

	static rom_bin_info img = rom_bin_raw_get();
	rom_bin_raw_init(img, frame_buffer_a, LV_HOR_RES_MAX, LV_VER_RES_MAX);
	lv_obj_set_style_local_pattern_image(lv_scr_act(), LV_OBJ_PART_MAIN, LV_STATE_DEFAULT, &img);

	/***** 等待1加载后自动加载2 *****/
	lv_layout_task_create(frame_loading_1_buffer_copy_task, 3000, LV_TASK_PRIO_MID, NULL);
	lv_obj_invalidate(lv_scr_act());

	lv_task_del(task_t);
}

/***
** 日期: 2022-05-10 18:13
** 作者: leo.liu
** 函数作用：创建时间容器
** 返回参数说明：
***/
static void frame_show_time_cont_create(void)
{
	struct tm tm;
	user_time_read(&tm);

	lv_obj_t *cont = lv_cont_create(lv_scr_act(), NULL);
	lv_obj_set_id(cont, LAYOUT_FRAME_SHOW_OBJ_ID_FRAME_0_CONT);
	lv_obj_set_pos(cont, 451, 186);
	lv_obj_set_size(cont, 378, 227);
	home_time_text_create(cont, 0, 0, 378, 227, LAYOUT_FRAME_SHOW_OBJ_ID_FRAME_0_HOUR, LAYOUT_FRAME_SHOW_OBJ_ID_FRAME_0_MIN, LAYOUT_FRAME_SHOW_OBJ_ID_FRAME_0_DOT);
	home_time_refresh_display(cont, &tm, LAYOUT_FRAME_SHOW_OBJ_ID_FRAME_0_HOUR, LAYOUT_FRAME_SHOW_OBJ_ID_FRAME_0_MIN, LAYOUT_FRAME_SHOW_OBJ_ID_FRAME_0_DOT, false);

	cont = lv_cont_create(lv_scr_act(), NULL);
	lv_obj_set_id(cont, LAYOUT_FRAME_SHOW_OBJ_ID_FRAME_0_DATE_CONT);
	lv_obj_set_pos(cont, 451, 384);
	lv_obj_set_size(cont, 378, 41);
	home_date_text_create(cont, 0, 0, 384, 74, LAYOUT_FRAME_SHOW_OBJ_ID_FRAME_0_DATE_TXT);
	home_date_refresh_display(cont, &tm, LAYOUT_FRAME_SHOW_OBJ_ID_FRAME_0_DATE_TXT);
}

/***
**   日期:2022-05-26 10:16:27
**   作者: leo.liu
**   函数作用：等待解码器空闲
**   参数说明:
***/
static void frame_show_wait_decode_idle(void)
{
	printf("###decode wait ");
	while ((jpg_decode_device_state() == true) || (h264_decode_device_state() == true))
	{
		usleep(1 * 1000);
	}
	printf("finish ####\n");
}

static void LAYOUT_ENTER_FUNC(frame_show)
{
	frame_show_wait_decode_idle();

	standby_timer_close();
	/***** frame 页面初始化 *****/
	frame_show_layer_init();
	/***** 打开解码器 *****/
	jpg_decode_open(jpg_decode_frame_read_func);
	/***** 创建返回按钮 *****/
	frame_show_cancel_btn_create();
	/***** 创建设置按钮 *****/
	frame_show_setting_btn_create();
	/***** 创建时间容器 *****/
	frame_show_time_cont_create();
	/***** 等待1加载后自动加载2 *****/
	frame_display_decode_file_index = 0;
	frame_show_read_jpg_and_decode(FRAME_1_FILE_PATH);
	lv_layout_task_create(frame_loading_1_buffer_task, 20, LV_TASK_PRIO_MID, NULL);
}

static void LAYOUT_QUIT_FUNC(frame_show)
{

	const rom_bin_info *img = lv_obj_get_style_pattern_image(lv_scr_act(), LV_OBJ_PART_MAIN);
	lv_img_cache_invalidate_src(img);
	lv_obj_set_style_local_pattern_image(lv_scr_act(), LV_OBJ_PART_MAIN, LV_STATE_DEFAULT, NULL);

	jpg_decode_close();
	if (frame_buffer_a != NULL)
	{
		ak_mem_dma_free(frame_buffer_a);
		frame_buffer_a = NULL;
	}
	if (frame_buffer_cur_a != NULL)
	{
		ak_mem_dma_free(frame_buffer_cur_a);
		frame_buffer_cur_a = NULL;
	}
	if (frame_buffer_cur_b != NULL)
	{
		ak_mem_dma_free(frame_buffer_cur_b);
		frame_buffer_cur_b = NULL;
	}
	gui_refresh_enable(true);
	standby_timer_restart(true);
}

CREATE_LAYOUT(frame_show);
