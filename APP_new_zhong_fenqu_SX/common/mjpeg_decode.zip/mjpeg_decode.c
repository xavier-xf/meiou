#include "video_decode.h"
#include "user_common.h"
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <semaphore.h>
#include <unistd.h>
#include <sys/time.h>
#include <pthread.h>
#include <mqueue.h>
#include <stdio.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

/***** 解码后数据输出回调函数 *****/
static void (*jpg_decode_frame_read_callback)(struct ak_vdec_frame *) = NULL;

/***** 解码器任务队列 *****/
static int jpg_decode_queue_head = -1;

/*****  解码句柄 *****/
static int jpg_decode_handle_id = -1;

/***** 解码使能 *****/
static bool jpg_decode_enable = false;

static int jpg_decode_frame_count = 0;
/***
** 日期: 2022-05-10 11:23
** 作者: leo.liu
** 函数作用：打开解码器
** 返回参数说明：
***/
static void jpg_decode_device_open(void)
{
    struct ak_vdec_param param;
    memset(&param, 0, sizeof(struct ak_vdec_param));
    param.vdec_type = MJPEG_ENC_TYPE;
    param.output_type = AK_YUV420SP;
    param.sc_width = 1280;
    param.sc_height = 1080;
    param.stream_buf_size = 1024 * 1024;
    param.frame_buf_num = 3;
    ak_vdec_open(&param, &jpg_decode_handle_id);
    ak_vdec_clear_buff(jpg_decode_handle_id);
}

/***
** 日期: 2022-05-10 11:23
** 作者: leo.liu
** 函数作用：关闭解码器
** 返回参数说明：
***/
static void jpg_decode_device_close(void)
{
    ak_vdec_close(jpg_decode_handle_id);
    jpg_decode_handle_id = -1;
}

/***
** 日期: 2022-05-10 10:59
** 作者: leo.liu
** 函数作用：接收数据队列函数
** 返回参数说明：
***/
static void *jpg_stream_receive_task(void *arg)
{
    common_queue stream_data;
    while (msgrcv(jpg_decode_queue_head, (void *)&stream_data, sizeof(common_queue), 0, IPC_NOWAIT) > 0)
        ;

    printf("***** jpg stream task create sccess ! *****\n");
    while (1)
    {
        if (msgrcv(jpg_decode_queue_head, (void *)&stream_data, sizeof(common_queue), sizeof(common_data), IPC_NOWAIT) > 0)
        {
            if ((jpg_decode_enable == true) && (jpg_decode_handle_id == -1))
            {
                jpg_decode_device_open();
            }


            if (stream_data.msg.data == NULL)
            {
                printf("jpg deocde msg rev data error \n");
                goto finish;
            }
            if ((jpg_decode_enable == true) && (jpg_decode_handle_id != -1))
            {
                int dec_len = 0;
                int read_len = stream_data.msg.size;
                int send_len = 0;
                while (read_len > 0)
                {

                    ak_vdec_send_stream(jpg_decode_handle_id, &stream_data.msg.data[send_len], read_len, NONBLOCK, &dec_len);

                    read_len -= dec_len;
                    send_len += dec_len;
                }

                jpg_decode_frame_count++;
            }
            ak_mem_free(stream_data.msg.data);
        }
        else if ((jpg_decode_enable == false) && (jpg_decode_handle_id != -1))
        {
            if (jpg_decode_frame_count == 0)
            {
                jpg_decode_device_close();
            }
            else
            {
                printf("Wait for decoding to complete \n");
            }
        }
    finish:
        usleep(10*1000);
    }
    return NULL;
}

/***
** 日期: 2022-05-10 11:04
** 作者: leo.liu
** 函数作用：解码线程
** 返回参数说明：
***/
static void *jpg_decode_task(void *arg)
{
    struct ak_vdec_frame frame = {0};
    while (1)
    {
        if ((jpg_decode_handle_id != -1) && (jpg_decode_frame_count > 0))
        {
            memset(&frame, 0, sizeof(struct ak_vdec_frame));
            if (ak_vdec_get_frame(jpg_decode_handle_id, &frame) == 0)
            {
                if ((jpg_decode_enable == true) && (jpg_decode_frame_read_callback != NULL))
                {
                    jpg_decode_frame_read_callback(&frame);
                }
                ak_vdec_release_frame(jpg_decode_handle_id, &frame);
                jpg_decode_frame_count--;
                printf("The remaining frames are not decoded:%d \n", jpg_decode_frame_count);
            }
        }
        else
        {
            usleep(10*1000);
        }
    }

    return NULL;
}

/***
** 日期: 2022-05-10 10:55
** 作者: leo.liu
** 函数作用：jpg解码器初始化
** 返回参数说明：
***/
bool jpg_decode_init(void)
{
    static bool inited = false;
    if (inited == true)
    {
        printf("jpg decode It's already initialized \n");
        return false;
    }
    inited = true;

    jpg_decode_queue_head = msg_queue_create();

    pthread_t pthread;
    pthread_create(&pthread, NULL, jpg_stream_receive_task, NULL);
    pthread_create(&pthread, NULL, jpg_decode_task, NULL);
    return true;
}

/***
** 日期: 2022-05-10 12:02
** 作者: leo.liu
** 函数作用：打开jpg解码器
** 返回参数说明：
***/
bool jpg_decode_open(void (*read_frame)(struct ak_vdec_frame *frame))
{
    if (jpg_decode_enable == true)
    {
        return false;
    }
    jpg_decode_frame_read_callback = read_frame;
    jpg_decode_enable = true;
    return true;
}

/***
** 日期: 2022-05-10 13:33
** 作者: leo.liu
** 函数作用：
** 返回参数说明：
***/
bool jpg_decode_close(void)
{
    if (jpg_decode_enable == false)
    {
        return true;
    }
    jpg_decode_enable = false;
    return true;
}

/***
** 日期: 2022-05-10 13:37
** 作者: leo.liu
** 函数作用：写入解码流
** 返回参数说明：
***/
bool jpg_decode_stream_write(const unsigned char *data, int size)
{
    if (jpg_decode_enable == false)
    {
        return false;
    }
    common_queue stream;
    stream.type = sizeof(common_data);
    stream.msg.data = user_mem_copy(data, size);
    stream.msg.size = size;
    msgsnd(jpg_decode_queue_head, &stream, stream.type, 0);
    return true;
}

/***
** 日期: 2022-05-10 13:41
** 作者: leo.liu
** 函数作用：判断解码线程是否彻底关闭
** 返回参数说明：
***/
bool is_jpg_decode_device_close(void)
{
    return jpg_decode_handle_id == -1 ? true : false;
}