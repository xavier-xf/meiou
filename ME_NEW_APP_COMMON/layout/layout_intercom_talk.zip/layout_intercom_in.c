#include "layout_define.h"
typedef enum
{
	intercom_in_sct_act_obj_id_head_cont,
	intercom_in_sct_act_obj_id_timeout_label,
	intercom_in_sct_act_obj_id_callid_label,
	intercom_in_sct_act_obj_id_vol_btn,
	intercom_in_sct_act_obj_id_handup_btn,
	intercom_in_sct_act_obj_id_talk_btn,
	intercom_in_sct_act_obj_id_vol_cont,
	intercom_in_sct_act_obj_id_vol_bar,
} intercom_in_sct_act_obj_id;
void intercom_head_cont_crate(int obj_id, const char *string);
void intercom_timeout_label_create(int obj_id, int timeout);
void intercom_intercom_icon_create(bool talk);
void intercom_call_id_label_create(int obj_id);
void intercom_call_id_label_display(int find_id);
void intercom_vol_btn_create(int obj_id, bool talk, const obj_click_data *click_data);
void intercom_call_handup_and_talk_create(int x, int obj_id, const obj_click_data *click_data, bool talk);
void intercom_vol_cont_create(int cont_id, int bar_id, const obj_click_data *left, const obj_click_data *right, int vol);
void intercom_obj_hidden(int vol_id, int talk_id, int hand_up, bool en, int cont_id, void (*vol_other_up)(lv_obj_t *obj));

static void intercom_in_vol_other_up(lv_obj_t *obj)
{
	lv_point_t point;
	lv_indev_get_point(lv_indev_get_act(), &point);
	if (point.y > 680)
	{
		return;
	}
	intercom_obj_hidden(intercom_in_sct_act_obj_id_vol_btn, intercom_in_sct_act_obj_id_talk_btn, intercom_in_sct_act_obj_id_handup_btn, false, intercom_in_sct_act_obj_id_vol_cont, NULL);
}
/***
**   日期:2022-05-30 15:19:11
**   作者: leo.liu
**   函数作用：音量按钮被按下
**   参数说明:
***/
static void intercom_in_vol_btn_up(lv_obj_t *obj)
{
	intercom_obj_hidden(intercom_in_sct_act_obj_id_vol_btn, intercom_in_sct_act_obj_id_talk_btn, intercom_in_sct_act_obj_id_handup_btn, true, intercom_in_sct_act_obj_id_vol_cont, intercom_in_vol_other_up);
}
static void intercom_in_left_up(lv_obj_t *obj)
{
	lv_obj_t *parent = lv_obj_get_child_form_id(lv_scr_act(), intercom_in_sct_act_obj_id_vol_cont);
	lv_obj_t *bar = lv_obj_get_child_form_id(parent, intercom_in_sct_act_obj_id_vol_bar);
	lv_obj_t *label = lv_obj_get_child_form_id(parent, intercom_in_sct_act_obj_id_vol_bar + 1);
	if (bar && label)
	{
		int vol = lv_bar_get_value(bar);
		if (vol > 0)
		{
			vol--;
			user_data_get()->audio.inter_ring_volume = vol;
			user_data_save();
			lv_bar_set_value(bar, vol, true);
			lv_label_set_text_fmt(label, "%d", vol);
		}
	}
}
static void intercom_in_right_up(lv_obj_t *obj)
{
	lv_obj_t *parent = lv_obj_get_child_form_id(lv_scr_act(), intercom_in_sct_act_obj_id_vol_cont);
	lv_obj_t *bar = lv_obj_get_child_form_id(parent, intercom_in_sct_act_obj_id_vol_bar);
	lv_obj_t *label = lv_obj_get_child_form_id(parent, intercom_in_sct_act_obj_id_vol_bar + 1);
	if (bar && label)
	{
		int vol = lv_bar_get_value(bar);
		if (vol < 3)
		{
			vol++;
			user_data_get()->audio.inter_ring_volume = vol;
			user_data_save();
			lv_bar_set_value(bar, vol, true);
			lv_label_set_text_fmt(label, "%d", vol);
		}
	}
}
static void intercom_in_talk_up(lv_obj_t *obj)
{
	intercom_cmd_send(CODE_ALL_ID, CMD_INTERPHONE_ANSWER);
	goto_layout(pLAYOUT(intercom_talk));
}
static void intercom_in_handup_up(lv_obj_t *obj)
{
	goto_layout(pLAYOUT(home));
}
static void LAYOUT_ENTER_FUNC(intercom_in)
{
	intercom_head_cont_crate(intercom_in_sct_act_obj_id_head_cont, layout_intercom_string_get(LAYOUT_INTERCOM_LANGUAGE_ID_CALLING));
	intercom_timeout_label_create(intercom_in_sct_act_obj_id_timeout_label, 30);
	intercom_intercom_icon_create(false);
	intercom_call_id_label_create(intercom_in_sct_act_obj_id_callid_label);
	intercom_call_id_label_display(intercom_in_sct_act_obj_id_callid_label);
	static obj_click_data click_data_1 = obj_click_data_up_create(intercom_in_vol_btn_up);
	intercom_vol_btn_create(intercom_in_sct_act_obj_id_vol_btn, false, &click_data_1);
	static obj_click_data click_data_2 = obj_click_data_up_create(intercom_in_handup_up);
	intercom_call_handup_and_talk_create(650, intercom_in_sct_act_obj_id_handup_btn, &click_data_2, false);
	static obj_click_data click_data_3 = obj_click_data_up_create(intercom_in_talk_up);
	intercom_call_handup_and_talk_create(498, intercom_in_sct_act_obj_id_talk_btn, &click_data_3, true);
	static obj_click_data left = obj_click_data_up_create(intercom_in_left_up);
	static obj_click_data right = obj_click_data_up_create(intercom_in_right_up);
	intercom_vol_cont_create(intercom_in_sct_act_obj_id_vol_cont, intercom_in_sct_act_obj_id_vol_bar, &left, &right, user_data_get()->audio.inter_ring_volume);

	door_audio_talk(AUDIO_CH_CLOSE);
	if ((user_data_get()->audio.ring_mute == false) && (user_data_get()->audio.inter_ring_volume != 0))
	{
		ring_output_gpio_ctrl_volume(user_data_get()->audio.inter_ring_volume);
		ringplay_play_form_index(user_data_get()->audio.inter_tone, 100, ringplay_intercom_start_default_func, ringplay_intercom_finish_default_func, false);
	}
}
static void LAYOUT_QUIT_FUNC(intercom_in)
{
	const layout *p = cur_layout_get();
	if (p != pLAYOUT(intercom_talk))
	{
		intercom_cmd_send(layout_intercom_call_mask_get(), CMD_INTERPHONE_QUIT);
	}
}
CREATE_LAYOUT(intercom_in);