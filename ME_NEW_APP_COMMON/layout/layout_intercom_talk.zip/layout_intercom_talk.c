#include "layout_define.h"
typedef enum
{
	intercom_talk_sct_act_obj_id_head_cont,
	intercom_talk_sct_act_obj_id_timeout_label,
	intercom_talk_sct_act_obj_id_callid_label,
	intercom_talk_sct_act_obj_id_vol_btn,
	intercom_talk_sct_act_obj_id_handup_btn,
	intercom_talk_sct_act_obj_id_vol_cont,
	intercom_talk_sct_act_obj_id_vol_bar,
} intercom_in_sct_act_obj_id;
void intercom_head_cont_crate(int obj_id, const char *string);
void intercom_timeout_label_create(int obj_id, int timeout);
void intercom_intercom_icon_create(bool talk);
void intercom_call_id_label_create(int obj_id);
void intercom_call_id_label_display(int find_id);
void intercom_vol_btn_create(int obj_id, bool talk, const obj_click_data *click_data);
void intercom_call_handup_and_talk_create(int x, int obj_id, const obj_click_data *click_data, bool talk);
void intercom_vol_cont_create(int cont_id, int bar_id, const obj_click_data *left, const obj_click_data *right, int vol);
void intercom_obj_hidden(int vol_id, int talk_id, int hand_up, bool en, int cont_id, void (*vol_other_up)(lv_obj_t *obj));

static void intercom_talk_vol_other_up(lv_obj_t *obj)
{
	lv_point_t point;
	lv_indev_get_point(lv_indev_get_act(), &point);
	if (point.y > 680)
	{
		return;
	}
	intercom_obj_hidden(intercom_talk_sct_act_obj_id_vol_btn, -1, intercom_talk_sct_act_obj_id_handup_btn, false, intercom_talk_sct_act_obj_id_vol_cont, NULL);
}
/***
**   日期:2022-05-30 15:19:11
**   作者: leo.liu
**   函数作用：音量按钮被按下
**   参数说明:
***/
static void intercom_talk_vol_btn_up(lv_obj_t *obj)
{
	intercom_obj_hidden(intercom_talk_sct_act_obj_id_vol_btn, -1, intercom_talk_sct_act_obj_id_handup_btn, true, intercom_talk_sct_act_obj_id_vol_cont, intercom_talk_vol_other_up);
}
static void intercom_talk_left_up(lv_obj_t *obj)
{
	lv_obj_t *parent = lv_obj_get_child_form_id(lv_scr_act(), intercom_talk_sct_act_obj_id_vol_cont);
	lv_obj_t *bar = lv_obj_get_child_form_id(parent, intercom_talk_sct_act_obj_id_vol_bar);
	lv_obj_t *label = lv_obj_get_child_form_id(parent, intercom_talk_sct_act_obj_id_vol_bar + 1);
	if (bar && label)
	{
		int vol = lv_bar_get_value(bar);
		if (vol > 0)
		{
			vol--;
			user_data_get()->audio.inter_talk_volume = vol;
			user_data_save();
			lv_bar_set_value(bar, vol, true);
			lv_label_set_text_fmt(label, "%d", vol);
			talk_output_gpio_ctrl_volume(vol);
		}
	}
}
static void intercom_talk_right_up(lv_obj_t *obj)
{
	lv_obj_t *parent = lv_obj_get_child_form_id(lv_scr_act(), intercom_talk_sct_act_obj_id_vol_cont);
	lv_obj_t *bar = lv_obj_get_child_form_id(parent, intercom_talk_sct_act_obj_id_vol_bar);
	lv_obj_t *label = lv_obj_get_child_form_id(parent, intercom_talk_sct_act_obj_id_vol_bar + 1);
	if (bar && label)
	{
		int vol = lv_bar_get_value(bar);
		if (vol < 3)
		{
			vol++;
			user_data_get()->audio.inter_talk_volume = vol;
			user_data_save();
			lv_bar_set_value(bar, vol, true);
			lv_label_set_text_fmt(label, "%d", vol);
			talk_output_gpio_ctrl_volume(vol);
		}
	}
}
/***
**   日期:2022-05-31 14:06:44
**   作者: leo.liu
**   函数作用：判断mask是否发生变化
**   参数说明:
***/
static void intercom_talk_id_label_task(lv_task_t *task_t)
{
	unsigned int *mask = (unsigned int *)task_t->user_data;
	if ((*mask) != layout_intercom_call_mask_get())
	{
		*mask = layout_intercom_call_mask_get();
		intercom_call_id_label_display(intercom_talk_sct_act_obj_id_callid_label);
	}
}
/***
** 日期: 2022-04-28 09:53
** 作者: leo.liu
** 函数作用：监控被按下执行的回调函数
** 返回参数说明：
***/
void layout_intercom_talk_click_down_func(lv_obj_t *obj)
{
	//***** 控制声音流向 *****/
	touch_sound_play(NULL, NULL);
}

static void intercom_talk_handup_up(lv_obj_t *obj)
{
	goto_layout(pLAYOUT(home));
}
static void LAYOUT_ENTER_FUNC(intercom_talk)
{
	intercom_head_cont_crate(intercom_talk_sct_act_obj_id_head_cont, layout_intercom_string_get(LAYOUT_INTERCOM_LANGUAGE_ID_TALKING));
	intercom_timeout_label_create(intercom_talk_sct_act_obj_id_timeout_label, 60);
	intercom_intercom_icon_create(true);
	intercom_call_id_label_create(intercom_talk_sct_act_obj_id_callid_label);
	intercom_call_id_label_display(intercom_talk_sct_act_obj_id_callid_label);
	static obj_click_data click_data_1 = obj_click_data_up_create(intercom_talk_vol_btn_up);
	intercom_vol_btn_create(intercom_talk_sct_act_obj_id_vol_btn, true, &click_data_1);
	static obj_click_data click_data_2 = obj_click_data_up_create(intercom_talk_handup_up);
	intercom_call_handup_and_talk_create(574, intercom_talk_sct_act_obj_id_handup_btn, &click_data_2, false);
	static obj_click_data left = obj_click_data_up_create(intercom_talk_left_up);
	static obj_click_data right = obj_click_data_up_create(intercom_talk_right_up);
	intercom_vol_cont_create(intercom_talk_sct_act_obj_id_vol_cont, intercom_talk_sct_act_obj_id_vol_bar, &left, &right, user_data_get()->audio.inter_talk_volume);

	static unsigned int mask = 0;
	mask = layout_intercom_call_mask_get();
	lv_layout_task_create(intercom_talk_id_label_task, 1000, LV_TASK_PRIO_MID, &mask);

	ringplay_play_stop();
	lv_obj_click_down_callback_register(layout_intercom_talk_click_down_func);
	door_audio_talk(AUDIO_CH_INTER);
}
static void LAYOUT_QUIT_FUNC(intercom_talk)
{
	lv_obj_click_down_callback_register(layout_obj_click_down_func);
	door_audio_talk(AUDIO_CH_CLOSE);
	intercom_cmd_send(CODE_ALL_ID, CMD_DATA_RELEASE);
}
CREATE_LAYOUT(intercom_talk);