#include "layout_define.h"

typedef enum
{
	intercom_out_sct_act_obj_id_head_cont,
	intercom_out_sct_act_obj_id_timeout_label,
	intercom_out_sct_act_obj_id_callid_label,
	intercom_out_sct_act_obj_id_vol_btn,
	intercom_out_sct_act_obj_id_handup_btn,
	intercom_out_sct_act_obj_id_vol_cont,
	intercom_out_sct_act_obj_id_vol_bar,
} intercom_out_sct_act_obj_id;
unsigned int layout_intercom_call_mask_get(void);
/***
**   日期:2022-05-30 15:05:27
**   作者: leo.liu
**   函数作用：创建顶部容器
**   参数说明:
***/
void intercom_head_cont_crate(int obj_id, const char *string)
{
	lv_obj_t *cont = lv_cont_create(lv_scr_act(), NULL);
	lv_obj_set_id(cont, obj_id);
	lv_obj_set_pos(cont, 0, 0);
	lv_obj_set_size(cont, 1280, 90);
	lv_obj_set_style_local_bg_opa(cont, LV_CONT_PART_MAIN, LV_STATE_DEFAULT, LV_OPA_COVER);
	lv_obj_set_style_local_bg_color(cont, LV_CONT_PART_MAIN, LV_STATE_DEFAULT, lv_color_hex(0x00));
	lv_obj_set_style_local_value_str(cont, LV_CONT_PART_MAIN, LV_STATE_DEFAULT, string);
	lv_obj_set_style_local_value_align(cont, LV_CONT_PART_MAIN, LV_STATE_DEFAULT, LV_ALIGN_IN_LEFT_MID);
	lv_obj_set_style_local_value_ofs_x(cont, LV_CONT_PART_MAIN, LV_STATE_DEFAULT, 20);
}

/***
**   日期:2022-05-30 16:41:18
**   作者: leo.liu
**   函数作用：超时任务
**   参数说明:
***/
static void intercom_timeout_task(lv_task_t *task_t)
{
	lv_obj_t *label = (lv_obj_t *)task_t->user_data;
	int timeout = *((int *)label->user_data);
	if (timeout == 0)
	{
		goto_layout(pLAYOUT(home));
	}
	else
	{
		timeout--;
		*((int *)label->user_data) = timeout;
		lv_label_set_text_fmt(label, "%02d:%02d", timeout / 60, timeout % 60);
	}
}
/***
**   日期:2022-05-30 15:06:44
**   作者: leo.liu
**   函数作用：创建超时文本
**   参数说明:
***/
void intercom_timeout_label_create(int obj_id, int t)
{
	lv_obj_t *label = lv_label_create(lv_scr_act(), NULL);
	lv_obj_set_id(label, obj_id);
	lv_label_set_long_mode(label, LV_LABEL_LONG_CROP);
	lv_obj_set_pos(label, 1160, 30);
	lv_obj_set_size(label, 80, 43);
	lv_label_set_align(label, LV_LABEL_ALIGN_RIGHT);
	static int timeout = 0;
	label->user_data = &timeout;
	timeout = t;
	lv_label_set_text_fmt(label, "%02d:%02d", timeout / 60, timeout % 60);
	lv_layout_task_create(intercom_timeout_task, 1000, LV_TASK_PRIO_MID, label);
}
/***
**   日期:2022-05-30 15:08:42
**   作者: leo.liu
**   函数作用：创建intercom图标
**   参数说明:
***/
void intercom_intercom_icon_create(bool talk)
{
	lv_obj_t *obj = lv_obj_create(lv_scr_act(), NULL);
	lv_obj_set_pos(obj, 379, 170);
	lv_obj_set_size(obj, 522, 420);

	static rom_bin_info img_call = rom_bin_info_get(ROM_UI_1_WAIT_PNG);
	static rom_bin_info img_talk = rom_bin_info_get(ROM_UI_2_TALK_PNG);
	lv_obj_set_style_local_pattern_image(obj, LV_OBJ_PART_MAIN, LV_STATE_DEFAULT, talk == true ? &img_talk : &img_call);
	lv_obj_set_click(obj, false);
}

void intercom_call_id_label_display(int find_id)
{
	lv_obj_t *label = lv_obj_get_child_form_id(lv_scr_act(), find_id);
	if (label == NULL)
	{
		return;
	}

	unsigned int flag = layout_intercom_call_mask_get();
	char buffer[128] = {0};
	if (flag & 0x01)
	{
		sprintf(&buffer[strlen(buffer)], "%s %s\n", ((flag & 0x100) == 0x100) ? "#0096ff" : "#FFFFFF", layout_setting_etc_string_get(SETTING_ETC_LANG_ID_DEVICE_ID1));
	}
	if (flag & 0x02)
	{
		sprintf(&buffer[strlen(buffer)], "%s %s\n", ((flag & 0x200) == 0x200) ? "#0096ff" : "#FFFFFF", layout_setting_etc_string_get(SETTING_ETC_LANG_ID_DEVICE_ID2));
	}
	if (flag & 0x04)
	{
		sprintf(&buffer[strlen(buffer)], "%s %s\n", ((flag & 0x400) == 0x400) ? "#0096ff" : "#FFFFFF", layout_setting_etc_string_get(SETTING_ETC_LANG_ID_DEVICE_ID3));
	}
	if (flag & 0x08)
	{
		sprintf(&buffer[strlen(buffer)], "%s %s\n", ((flag & 0x800) == 0x800) ? "#0096ff" : "#FFFFFF", layout_setting_etc_string_get(SETTING_ETC_LANG_ID_DEVICE_ID4));
	}
	lv_label_set_text(label, buffer);
	int h = lv_obj_get_height(label);
	int y = 170 + (396 - h) / 2;
	lv_obj_set_y(label, y);
}
/***
**   日期:2022-05-30 15:12:57
**   作者: leo.liu
**   函数作用：显示label
**   参数说明:
***/
void intercom_call_id_label_create(int obj_id)
{
	lv_obj_t *label = lv_label_create(lv_scr_act(), NULL);
	lv_obj_set_id(label, obj_id);
	lv_label_set_long_mode(label, LV_LABEL_LONG_BREAK);
	lv_label_set_recolor(label, true);
	lv_obj_set_pos(label, 442, 170);
	lv_obj_set_size(label, 396, 396);
	lv_label_set_align(label, LV_LABEL_ALIGN_CENTER);
	lv_obj_set_style_local_text_font(label, LV_LABEL_PART_MAIN, LV_STATE_DEFAULT, FONT_SIZE(31));
}
/***
**   日期:2022-05-30 15:16:05
**   作者: leo.liu
**   函数作用：音量图标创建
**   参数说明:
***/
void intercom_vol_btn_create(int obj_id, bool talk, const obj_click_data *click_data)
{
	lv_obj_t *obj = lv_obj_create(lv_scr_act(), NULL);
	lv_obj_set_id(obj, obj_id);
	lv_obj_set_pos(obj, 60, 670);
	lv_obj_set_size(obj, 100, 100);
	static rom_bin_info img_call = rom_bin_info_get(ROM_UI_12_CALL_SOUND_PNG);
	static rom_bin_info img_talk = rom_bin_info_get(ROM_UI_13_TALK_SOUND_PNG);
	lv_obj_set_style_local_pattern_image(obj, LV_OBJ_PART_MAIN, LV_STATE_DEFAULT, talk ? &img_talk : &img_call);
	obj_click_event_listen(obj, click_data);
}

/***
**   日期:2022-05-30 15:32:16
**   作者: leo.liu
**   函数作用：隐藏和显示按钮
**   参数说明:
***/
void intercom_obj_hidden(int vol_id, int talk_id, int hand_up, bool en, int cont_id, void (*vol_other_up)(lv_obj_t *obj))
{
	if (vol_id > 0)
	{
		lv_obj_t *obj = lv_obj_get_child_form_id(lv_scr_act(), vol_id);
		lv_obj_set_hidden(obj, en);
	}
	if (talk_id > 0)
	{
		lv_obj_t *obj = lv_obj_get_child_form_id(lv_scr_act(), talk_id);
		lv_obj_set_hidden(obj, en);
	}
	if (hand_up > 0)
	{
		lv_obj_t *obj = lv_obj_get_child_form_id(lv_scr_act(), hand_up);
		lv_obj_set_hidden(obj, en);
	}
	if (cont_id > 0)
	{
		lv_obj_t *obj = lv_obj_get_child_form_id(lv_scr_act(), cont_id);
		lv_obj_set_hidden(obj, !en);
		lv_obj_set_ext_click_area(obj, 0, 0, en == true ? 680 : 0, 0);
		static obj_click_data click_data = obj_click_data_up_create(NULL);
		click_data.up = vol_other_up;
		obj_click_event_listen(obj, &click_data);
	}
}
static void intercom_in_vol_other_up(lv_obj_t *obj)
{
	lv_point_t point;
	lv_indev_get_point(lv_indev_get_act(), &point);
	if (point.y > 680)
	{
		return;
	}
	intercom_obj_hidden(intercom_out_sct_act_obj_id_vol_btn, -1, intercom_out_sct_act_obj_id_handup_btn, false, intercom_out_sct_act_obj_id_vol_cont, NULL);
}
/***
**   日期:2022-05-30 15:19:11
**   作者: leo.liu
**   函数作用：音量按钮被按下
**   参数说明:
***/
static void intercom_in_vol_btn_up(lv_obj_t *obj)
{
	intercom_obj_hidden(intercom_out_sct_act_obj_id_vol_btn, -1, intercom_out_sct_act_obj_id_handup_btn, true, intercom_out_sct_act_obj_id_vol_cont, intercom_in_vol_other_up);
}

/***
**   日期:2022-05-30 15:19:48
**   作者: leo.liu
**   函数作用：挂断按钮创建
**   参数说明:
***/
void intercom_call_handup_and_talk_create(int x, int obj_id, const obj_click_data *click_data, bool talk)
{
	lv_obj_t *obj = lv_obj_create(lv_scr_act(), NULL);
	lv_obj_set_id(obj, obj_id);
	lv_obj_set_pos(obj, x, 644);
	lv_obj_set_size(obj, 132, 132);
	static rom_bin_info img_handup = rom_bin_info_get(ROM_UI_1_CALL_ENDCALL_PNG);
	static rom_bin_info img_talk = rom_bin_info_get(ROM_UI_3_CALL_CALL_PNG);
	lv_obj_set_style_local_pattern_image(obj, LV_OBJ_PART_MAIN, LV_STATE_DEFAULT, talk == true ? &img_talk : &img_handup);
	obj_click_event_listen(obj, click_data);
}

/***
**   日期:2022-05-30 15:21:09
**   作者: leo.liu
**   函数作用：创建
**   参数说明:
***/
static void intercom_out_handup_up(lv_obj_t *obj)
{
	goto_layout(pLAYOUT(home));
}

/***
** 日期: 2022-05-06 13:58
** 作者: leo.liu
** 函数作用：音量设置进度条的基础函数
** 返回参数说明：
***/
static void intercom_vol_bar_base_create(lv_obj_t *parent, int x, int y, int w, const obj_click_data *left_click, const obj_click_data *right_click, int bar_id, int vol)
{
	/***** bar *****/
	lv_obj_t *bar = lv_bar_create(parent ? parent : lv_scr_act(), NULL);
	lv_obj_set_id(bar, bar_id);
	lv_obj_set_pos(bar, x, y + 22);
	lv_obj_set_size(bar, w, 8);
	lv_bar_set_range(bar, 0, 3);
	lv_bar_set_value(bar, vol, false);

	lv_obj_set_style_local_bg_opa(bar, LV_BAR_PART_BG, LV_STATE_DEFAULT, LV_OPA_COVER);
	lv_obj_set_style_local_bg_color(bar, LV_BAR_PART_BG, LV_STATE_DEFAULT, lv_color_hex(0x666666));
	lv_obj_set_style_local_bg_color(bar, LV_BAR_PART_INDIC, LV_STATE_DEFAULT, lv_color_hex(0x0096ff));

	/***** btn *****/
	lv_obj_t *left_obj = lv_obj_create(parent ? parent : lv_scr_act(), NULL);
	lv_obj_set_pos(left_obj, x - 60, y);
	lv_obj_set_size(left_obj, 54, 54);
	static rom_bin_info left_img = rom_bin_info_get(ROM_UI_VOL_SUB_PNG);
	lv_obj_set_style_local_pattern_image(left_obj, LV_OBJ_PART_MAIN, LV_STATE_DEFAULT, &left_img);
	obj_click_event_listen(left_obj, left_click);

	lv_obj_t *right_obj = lv_obj_create(parent ? parent : lv_scr_act(), left_obj);
	lv_obj_set_x(right_obj, x + w);
	static rom_bin_info right_img = rom_bin_info_get(ROM_UI_VOL_ADD_PNG);
	lv_obj_set_style_local_pattern_image(right_obj, LV_OBJ_PART_MAIN, LV_STATE_DEFAULT, &right_img);
	obj_click_event_listen(right_obj, right_click);

	/***** label *****/
	lv_obj_t *label = lv_label_create(parent ? parent : lv_scr_act(), NULL);
	lv_obj_set_id(label, bar_id + 1);
	lv_obj_set_style_local_text_font(label, LV_LABEL_PART_MAIN, LV_STATE_DEFAULT, FONT_SIZE(31));
	lv_label_set_text_fmt(label, "%02d", vol);
	lv_obj_align(label, left_obj, LV_ALIGN_IN_LEFT_MID, -40, 0);
	lv_obj_set_auto_realign(label, true);
}
/***
**   日期:2022-05-30 15:25:37
**   作者: leo.liu
**   函数作用：创建音量容器
**   参数说明:
***/
void intercom_vol_cont_create(int cont_id, int bar_id, const obj_click_data *left, const obj_click_data *right, int vol)
{
	lv_obj_t *cont = lv_cont_create(lv_scr_act(), NULL);
	lv_obj_set_id(cont, cont_id);
	lv_obj_set_pos(cont, 0, 680);
	lv_obj_set_size(cont, 1280, 120);
	lv_obj_set_style_local_bg_opa(cont, LV_CONT_PART_MAIN, LV_STATE_DEFAULT, LV_OPA_COVER);
	lv_obj_set_style_local_bg_color(cont, LV_CONT_PART_MAIN, LV_STATE_DEFAULT, lv_color_hex(0x00));
	lv_obj_set_click(cont, false);
	lv_obj_set_hidden(cont, true);
	intercom_vol_bar_base_create(cont, 243, 35, 815, left, right, bar_id, vol);
}

static void intercom_out_left_up(lv_obj_t *obj)
{
	lv_obj_t *parent = lv_obj_get_child_form_id(lv_scr_act(), intercom_out_sct_act_obj_id_vol_cont);
	lv_obj_t *bar = lv_obj_get_child_form_id(parent, intercom_out_sct_act_obj_id_vol_bar);
	lv_obj_t *label = lv_obj_get_child_form_id(parent, intercom_out_sct_act_obj_id_vol_bar + 1);
	if (bar && label)
	{
		int vol = lv_bar_get_value(bar);
		if (vol > 0)
		{
			vol--;
			user_data_get()->audio.inter_ring_volume = vol;
			user_data_save();
			lv_bar_set_value(bar, vol, true);
			lv_label_set_text_fmt(label, "%d", vol);
		}
	}
}
static void intercom_out_right_up(lv_obj_t *obj)
{
	lv_obj_t *parent = lv_obj_get_child_form_id(lv_scr_act(), intercom_out_sct_act_obj_id_vol_cont);
	lv_obj_t *bar = lv_obj_get_child_form_id(parent, intercom_out_sct_act_obj_id_vol_bar);
	lv_obj_t *label = lv_obj_get_child_form_id(parent, intercom_out_sct_act_obj_id_vol_bar + 1);
	if (bar && label)
	{
		int vol = lv_bar_get_value(bar);
		if (vol < 3)
		{
			vol++;
			user_data_get()->audio.inter_ring_volume = vol;
			user_data_save();
			lv_bar_set_value(bar, vol, true);
			lv_label_set_text_fmt(label, "%d", vol);
		}
	}
}
static void LAYOUT_ENTER_FUNC(intercom_out)
{
	intercom_head_cont_crate(intercom_out_sct_act_obj_id_head_cont, layout_intercom_string_get(LAYOUT_INTERCOM_LANGUAGE_ID_CALLING));
	intercom_timeout_label_create(intercom_out_sct_act_obj_id_timeout_label, 30);
	intercom_intercom_icon_create(false);
	intercom_call_id_label_create(intercom_out_sct_act_obj_id_callid_label);
	intercom_call_id_label_display(intercom_out_sct_act_obj_id_callid_label);
	static obj_click_data click_data_1 = obj_click_data_up_create(intercom_in_vol_btn_up);
	intercom_vol_btn_create(intercom_out_sct_act_obj_id_vol_btn, false, &click_data_1);
	static obj_click_data click_data_2 = obj_click_data_up_create(intercom_out_handup_up);
	intercom_call_handup_and_talk_create(574, intercom_out_sct_act_obj_id_handup_btn, &click_data_2, false);
	static obj_click_data left = obj_click_data_up_create(intercom_out_left_up);
	static obj_click_data right = obj_click_data_up_create(intercom_out_right_up);
	intercom_vol_cont_create(intercom_out_sct_act_obj_id_vol_cont, intercom_out_sct_act_obj_id_vol_bar, &left, &right, user_data_get()->audio.inter_ring_volume);
	if ((user_data_get()->audio.ring_mute == false) && (user_data_get()->audio.inter_ring_volume != 0))
	{
		ring_output_gpio_ctrl_volume(user_data_get()->audio.inter_ring_volume);
		ringplay_play_form_index(user_data_get()->audio.inter_tone, 100, ringplay_intercom_start_default_func, ringplay_intercom_finish_default_func, false);
	}
}
static void LAYOUT_QUIT_FUNC(intercom_out)
{
	const layout *p = cur_layout_get();
	if ((intercom_mastar_id_get() == OwnID) && (p != pLAYOUT(intercom_talk)) && (p != pLAYOUT(monitor)))
	{
		usleep(200 * 1000);
		intercom_cmd_send(CODE_ALL_ID, CMD_DATA_RELEASE);
	}
}
CREATE_LAYOUT(intercom_out);